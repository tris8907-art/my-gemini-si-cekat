import React, { useState, useEffect, useCallback } from 'react';
import { Flame, ClipboardCheck, LayoutDashboard, History, LogOut, RefreshCw, Settings } from 'lucide-react';
import Dashboard from './components/Dashboard';
import ChecklistForm from './components/ChecklistForm';
import ReportTable from './components/ReportTable';
import Login from './components/Login';
import { InspectionData, AIConfig } from './types';
import { generateDraftMessage } from './services/geminiService';
import { DEFAULT_AI_CONFIG } from './constants';

const App: React.FC = () => {
  // Inisialisasi state langsung dari localStorage untuk persistensi instan saat reload
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('damkar_auth') === 'true';
  });

  const [userRole, setUserRole] = useState<'admin' | 'petugas' | null>(() => {
    return localStorage.getItem('damkar_role') as 'admin' | 'petugas' | null;
  });

  const [activeTab, setActiveTab] = useState<'dashboard' | 'checklist' | 'history'>('dashboard');
  
  const [history, setHistory] = useState<InspectionData[]>(() => {
    const saved = localStorage.getItem('damkar_reports');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return [];
      }
    }
    return [];
  });

  const [isSyncing, setIsSyncing] = useState(false);
  
  const [aiConfig, setAiConfig] = useState<AIConfig>(() => {
    const saved = localStorage.getItem('damkar_ai_config');
    return saved ? JSON.parse(saved) : DEFAULT_AI_CONFIG;
  });

  const updateAiConfig = (newConfig: AIConfig) => {
    setAiConfig(newConfig);
    localStorage.setItem('damkar_ai_config', JSON.stringify(newConfig));
  };

  const syncPendingReports = useCallback(async (currentHistory: InspectionData[]) => {
    const pending = currentHistory.filter(r => r.statusSync === 'pending');
    if (pending.length === 0 || !navigator.onLine) return;

    setIsSyncing(true);
    let updated = [...currentHistory];
    let changed = false;

    for (const report of pending) {
      try {
        const draft = await generateDraftMessage(report, aiConfig.draftInstruction);
        updated = updated.map(r => 
          r.id === report.id ? { ...r, aiDraft: draft, statusSync: 'synced' as const } : r
        );
        changed = true;
      } catch (e) {
        console.error("Gagal sinkronisasi laporan ID:", report.id);
      }
    }

    if (changed) {
      setHistory(updated);
      localStorage.setItem('damkar_reports', JSON.stringify(updated));
    }
    setIsSyncing(false);
  }, [aiConfig]);

  const handleLogin = (role: 'admin' | 'petugas') => {
    setIsLoggedIn(true);
    setUserRole(role);
    localStorage.setItem('damkar_auth', 'true');
    localStorage.setItem('damkar_role', role);
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserRole(null);
    localStorage.removeItem('damkar_auth');
    localStorage.removeItem('damkar_role');
  };

  const addReport = (report: InspectionData) => {
    const updated = [report, ...history];
    setHistory(updated);
    localStorage.setItem('damkar_reports', JSON.stringify(updated));
    if (navigator.onLine && report.statusSync === 'pending') {
      syncPendingReports(updated);
    }
    setActiveTab('history');
  };

  const deleteReport = (id: string) => {
    if (userRole !== 'admin') return;
    const updated = history.filter(r => r.id !== id);
    setHistory(updated);
    localStorage.setItem('damkar_reports', JSON.stringify(updated));
  };

  const resetHistory = () => {
    if (userRole !== 'admin') return;
    setHistory([]);
    localStorage.setItem('damkar_reports', JSON.stringify([]));
  };

  if (!isLoggedIn) return <Login onLogin={handleLogin} />;

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50 overflow-hidden relative">
      {/* Sidebar */}
      <aside className={`hidden md:flex flex-col w-64 ${userRole === 'admin' ? 'bg-slate-900' : 'bg-red-900'} text-white p-6 shadow-xl z-20`}>
        <div className="flex items-center gap-3 mb-10">
          <Flame size={28} className="text-red-500 fill-red-500" />
          <div>
            <h1 className="font-black text-xl leading-none">SI-CEKAT</h1>
            <p className="text-[9px] text-white/50 font-bold uppercase mt-1">
              {userRole === 'admin' ? 'KENDALI STRUKTUR' : 'OPERASIONAL'}
            </p>
          </div>
        </div>

        <nav className="flex-1 space-y-3">
          <NavItem 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
            icon={<LayoutDashboard size={20} />} 
            label={userRole === 'admin' ? 'Dashboard Kendali' : 'Monitor Armada'} 
          />
          <NavItem 
            active={activeTab === 'checklist'} 
            onClick={() => setActiveTab('checklist')} 
            icon={<ClipboardCheck size={20} />} 
            label="Input List Armada" 
          />
          <NavItem 
            active={activeTab === 'history'} 
            onClick={() => setActiveTab('history')} 
            icon={<History size={20} />} 
            label="Arsip Laporan" 
          />
        </nav>
        
        <button onClick={handleLogout} className="mt-auto flex items-center gap-3 p-4 rounded-2xl hover:bg-white/10 text-slate-300 font-black text-xs uppercase tracking-widest transition-all">
          <LogOut size={20} /> Keluar
        </button>
      </aside>

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {userRole === 'admin' && (
          <header className="bg-white border-b border-slate-200 p-4 px-8 flex items-center justify-between shadow-sm z-10 no-print">
            <div className="flex items-center gap-6">
              <h2 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                <Settings size={14} className="text-red-600" /> PANEL KENDALI ADMINISTRATOR
              </h2>
              {isSyncing && (
                <div className="flex items-center gap-2 text-red-600">
                  <RefreshCw className="animate-spin" size={14} />
                  <span className="text-[9px] font-black uppercase">Sync AI...</span>
                </div>
              )}
            </div>
            
            <button 
              onClick={handleLogout}
              className="flex items-center gap-2 text-red-600 hover:bg-red-50 px-4 py-2 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all border border-transparent hover:border-red-100"
            >
              <LogOut size={16} /> Keluar Sistem
            </button>
          </header>
        )}

        <div className={`flex-1 overflow-y-auto ${userRole === 'petugas' ? 'p-4 md:p-10' : 'p-4 md:p-8'} bg-slate-50/50`}>
          <div className="max-w-7xl mx-auto">
            {activeTab === 'dashboard' && (
              <Dashboard 
                reports={history} 
                userRole={userRole} 
                aiConfig={aiConfig} 
                onUpdateAiConfig={updateAiConfig} 
              />
            )}
            {activeTab === 'checklist' && <ChecklistForm onSubmit={addReport} userRole={userRole} />}
            {activeTab === 'history' && (
              <ReportTable 
                reports={history} 
                userRole={userRole} 
                onDelete={deleteReport} 
                onReset={resetHistory} 
              />
            )}
          </div>
        </div>

        <nav className="md:hidden bg-white border-t border-slate-200 flex items-stretch h-20 px-2 pb-safe no-print">
          <MobileNavItem active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} icon={<LayoutDashboard size={20} />} label="Monitor" />
          <MobileNavItem active={activeTab === 'checklist'} onClick={() => setActiveTab('checklist')} icon={<ClipboardCheck size={20} />} label="Input" />
          <MobileNavItem active={activeTab === 'history'} onClick={() => setActiveTab('history')} icon={<History size={20} />} label="Arsip" />
          <button onClick={handleLogout} className="flex-1 flex flex-col items-center justify-center gap-1 text-slate-400">
            <LogOut size={20} /> <span className="text-[10px] font-black uppercase">Keluar</span>
          </button>
        </nav>
      </main>
    </div>
  );
};

const NavItem = ({ active, onClick, icon, label }: any) => (
  <button onClick={onClick} className={`w-full flex items-center gap-3 p-4 rounded-2xl transition-all duration-300 text-xs font-black uppercase tracking-widest ${active ? 'bg-white text-slate-900 shadow-xl scale-105' : 'text-white/60 hover:bg-white/5 hover:text-white'}`}>
    {icon} {label}
  </button>
);

const MobileNavItem = ({ active, onClick, icon, label }: any) => (
  <button onClick={onClick} className={`flex-1 flex flex-col items-center justify-center gap-1 ${active ? 'text-red-600' : 'text-slate-400'}`}>
    {icon} <span className="text-[10px] font-black uppercase">{label}</span>
  </button>
);

export default App;