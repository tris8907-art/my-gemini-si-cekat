
import React, { useState, useEffect } from 'react';
import { Save, AlertTriangle, ClipboardCheck, Send, CheckCircle2, MessageSquare, Copy, X, RefreshCw, User, Truck, FileText } from 'lucide-react';
import { UNITS } from '../constants';
import { InspectionData, InspectionStatus, ReadinessStatus } from '../types';
import { generateDraftMessage } from '../services/geminiService';

interface Props {
  onSubmit: (data: InspectionData) => void;
  userRole?: 'admin' | 'petugas' | null;
}

const INITIAL_FORM_STATE = {
  personnelName: '',
  unitNumber: UNITS[0].name,
  odometer: 0,
  engineOilRadiator: InspectionStatus.AMAN,
  electricalLights: InspectionStatus.AMAN,
  sirenHorn: InspectionStatus.AMAN,
  tireCondition: InspectionStatus.AMAN,
  pumpPTO: InspectionStatus.AMAN,
  tankCondition: InspectionStatus.AMAN,
  hoseCondition: InspectionStatus.AMAN,
  nozzleCondition: InspectionStatus.AMAN,
  brakesCondition: InspectionStatus.AMAN,
  fuelLevel: 100,
  notes: ''
};

const ChecklistForm: React.FC<Props> = ({ onSubmit, userRole }) => {
  const [formData, setFormData] = useState<Partial<InspectionData>>(() => {
    // Muat draf dari localStorage jika ada
    const savedDraft = localStorage.getItem('damkar_form_draft');
    if (savedDraft) {
      try {
        return JSON.parse(savedDraft);
      } catch (e) {
        return INITIAL_FORM_STATE;
      }
    }
    return INITIAL_FORM_STATE;
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [aiDraft, setAiDraft] = useState<string>('');

  // Auto-save draf setiap kali formData berubah
  useEffect(() => {
    localStorage.setItem('damkar_form_draft', JSON.stringify(formData));
  }, [formData]);

  const calculateStatus = (data: Partial<InspectionData>): ReadinessStatus => {
    const criticalFails = [
      data.engineOilRadiator,
      data.brakesCondition,
      data.tireCondition
    ].filter(s => s === InspectionStatus.PERBAIKAN).length;

    const majorFails = [
      data.pumpPTO,
      data.tankCondition,
      data.electricalLights
    ].filter(s => s === InspectionStatus.PERBAIKAN).length;

    if (criticalFails > 0) return ReadinessStatus.OFF_SERVICE;
    if (majorFails > 0) return ReadinessStatus.SIAGA_TERBATAS;
    return ReadinessStatus.SIAGA;
  };

  const handleInputChange = (field: keyof InspectionData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleWhatsAppShare = (text: string) => {
    const encodedText = encodeURIComponent(text);
    window.open(`https://wa.me/?text=${encodedText}`, '_blank');
  };

  const formatDailyReport = (r: InspectionData) => {
    const unit = UNITS.find(u => u.name === r.unitNumber);
    const pos = unit ? unit.location : 'Pos Damkar Seluma';
    
    const date = new Date(r.timestamp);
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    
    const dayName = days[date.getDay()];
    const dateNum = date.getDate();
    const monthName = months[date.getMonth()];
    const year = date.getFullYear();
    
    const formattedDate = `${dayName}, ${dateNum} ${monthName} ${year}`;
    
    return `YUDHA BRAMA JAYA!
LAPORAN HARIAN KESIAPSIAGAAN ARMADA
PEMADAM KEBAKARAN KABUPATEN SELUMA
------------------------------------------
📅 Waktu: ${formattedDate}
🚛 Unit: ${r.unitNumber.toUpperCase()}
📍 Pos: ${pos}
------------------------------------------
🛑 STATUS OPERASIONAL: 🚒 ${r.status.toUpperCase()}
📟 Odometer: ${r.odometer} KM
------------------------------------------
⚙️ DATA TEKNIS KENDARAAN:
- Pompa PTO: ${r.pumpPTO}
- Sistem Rem: ${r.brakesCondition}
- Kapasitas Air: ${r.tankCondition}
- Kapasitas BBM: ${r.fuelLevel}%
- Kelistrikan: ${r.electricalLights}
------------------------------------------
🛠️ INVENTARIS PERALATAN:
- Selang (Hose): ${r.hoseCondition}
- Nozzle: ${r.nozzleCondition}
------------------------------------------
📝 CATATAN TEKNIS:
${r.notes || 'Kondisi terpantau aman dan terkendali.'}
------------------------------------------
👤 Petugas Pelapor: ${r.personnelName}
------------------------------------------
"PANTANG PULANG SEBELUM PADAM"
Laporan dikirim via SI-CEKAT Mobile`;
  };

  const [submittedReport, setSubmittedReport] = useState<InspectionData | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.personnelName || formData.personnelName.trim() === '') {
      alert("Harap masukkan nama personel pelapor.");
      return;
    }
    
    setIsSubmitting(true);
    const finalStatus = calculateStatus(formData);
    
    const report: InspectionData = {
      ...formData as InspectionData,
      id: `REP-${Date.now()}`,
      timestamp: new Date().toISOString(),
      status: finalStatus,
      statusSync: 'synced'
    };

    setSubmittedReport(report);
    onSubmit(report);
    
    // Hapus draf setelah berhasil kirim
    localStorage.removeItem('damkar_form_draft');
    
    setIsSubmitting(false);
    setShowSuccess(true);
    
    setFormData(INITIAL_FORM_STATE);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20">
      {showSuccess && (
        <div className="fixed inset-0 bg-slate-900/90 backdrop-blur-xl z-[150] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-xl rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="bg-green-600 p-10 text-white text-center relative">
              <div className="absolute top-4 right-4">
                <button onClick={() => setShowSuccess(false)} className="p-2 hover:bg-white/20 rounded-full transition-colors"><X size={24} /></button>
              </div>
              <CheckCircle2 size={72} className="mx-auto mb-4 animate-bounce" />
              <h3 className="text-2xl font-black uppercase italic tracking-tighter">Laporan Diarsipkan!</h3>
              <p className="text-green-100 text-[10px] font-bold uppercase tracking-widest mt-2">Data Berhasil Terinput ke Basis Data</p>
            </div>
            
            <div className="p-10 space-y-6">
              {submittedReport && (
                <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 space-y-4">
                  <div className="flex items-center gap-2 text-red-600 font-black text-[10px] uppercase tracking-widest">
                    <FileText size={14} /> Laporan Harian Armada
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-slate-200">
                    <pre className="text-[9px] font-mono text-slate-600 whitespace-pre-wrap leading-tight">
                      {formatDailyReport(submittedReport)}
                    </pre>
                  </div>
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText(formatDailyReport(submittedReport));
                        alert('Laporan disalin!');
                      }} 
                      className="bg-slate-900 text-white py-4 rounded-2xl font-black text-[10px] uppercase flex items-center justify-center gap-2 hover:bg-slate-800 transition-all active:scale-95 shadow-lg"
                    >
                      <Copy size={16} /> Salin Teks
                    </button>
                    <button 
                      onClick={() => handleWhatsAppShare(formatDailyReport(submittedReport))}
                      className="bg-[#25D366] text-white py-4 rounded-2xl font-black text-[10px] uppercase flex items-center justify-center gap-2 hover:bg-[#1da851] transition-all active:scale-95 shadow-lg shadow-green-100"
                    >
                      <Send size={16} /> WhatsApp
                    </button>
                  </div>
                </div>
              )}
              
              <button 
                onClick={() => setShowSuccess(false)} 
                className="w-full bg-slate-100 text-slate-900 py-5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all active:scale-95"
              >
                Tutup & Lanjut
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-100 overflow-hidden">
        <div className="bg-slate-900 p-10 text-white">
          <div className="flex items-center gap-4 mb-2">
            <ClipboardCheck size={32} className="text-red-500" />
            <h2 className="text-3xl font-black italic uppercase tracking-tighter">Input Kesiapan Armada</h2>
          </div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Damkar Kabupaten Seluma</p>
        </div>

        <form onSubmit={handleSubmit} className="p-10 space-y-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-3">
              <label className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1"><User size={14}/> Nama Personel Pelapor</label>
              <input 
                type="text"
                placeholder="Masukkan Nama Lengkap..."
                className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs text-slate-900 focus:border-red-600 outline-none transition-all"
                value={formData.personnelName}
                onChange={(e) => handleInputChange('personnelName', e.target.value)}
                required
              />
            </div>
            <div className="space-y-3">
              <label className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1"><Truck size={14}/> Pilih Unit Armada</label>
              <select 
                className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs text-slate-900 focus:border-red-600 outline-none transition-all cursor-pointer"
                value={formData.unitNumber}
                onChange={(e) => handleInputChange('unitNumber', e.target.value)}
              >
                {UNITS.map(unit => <option key={unit.id} value={unit.name}>{unit.name.toUpperCase()}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Odometer (KM)</label>
              <input 
                type="number" 
                className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-xs text-slate-900 focus:border-red-600 outline-none transition-all"
                value={formData.odometer}
                onChange={(e) => handleInputChange('odometer', parseInt(e.target.value))}
                required
              />
            </div>
            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Kapasitas BBM (%)</label>
              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border-2 border-slate-100">
                <input 
                  type="range" 
                  min="0" max="100" 
                  className="flex-1 accent-red-600"
                  value={formData.fuelLevel}
                  onChange={(e) => handleInputChange('fuelLevel', parseInt(e.target.value))}
                />
                <span className="font-black text-slate-900 text-lg w-12">{formData.fuelLevel}%</span>
              </div>
            </div>
          </div>

          <div className="h-px bg-slate-100"></div>

          <div className="space-y-6">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-[0.2em] mb-4 flex items-center gap-2"><AlertTriangle size={16} className="text-red-600" /> Pengecekan Sistem</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <CheckItem label="Oli & Radiator" field="engineOilRadiator" value={formData.engineOilRadiator!} onChange={handleInputChange} />
              <CheckItem label="Lampu & Rotator" field="electricalLights" value={formData.electricalLights!} onChange={handleInputChange} />
              <CheckItem label="Sirine & Klakson" field="sirenHorn" value={formData.sirenHorn!} onChange={handleInputChange} />
              <CheckItem label="Ban & Roda" field="tireCondition" value={formData.tireCondition!} onChange={handleInputChange} />
              <CheckItem label="Pompa & PTO" field="pumpPTO" value={formData.pumpPTO!} onChange={handleInputChange} />
              <CheckItem label="Tangki Air" field="tankCondition" value={formData.tankCondition!} onChange={handleInputChange} />
              <CheckItem label="Selang (Hose)" field="hoseCondition" value={formData.hoseCondition!} onChange={handleInputChange} />
              <CheckItem label="Nozzle" field="nozzleCondition" value={formData.nozzleCondition!} onChange={handleInputChange} />
              <CheckItem label="Sistem Rem" field="brakesCondition" value={formData.brakesCondition!} onChange={handleInputChange} />
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Catatan Tambahan</label>
            <textarea 
              className="w-full p-6 bg-slate-50 border-2 border-slate-100 rounded-3xl font-bold text-xs text-slate-900 focus:border-red-600 outline-none transition-all h-32"
              placeholder="Deskripsikan kondisi teknis lainnya..."
              value={formData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
            />
          </div>

          <button 
            type="submit" 
            disabled={isSubmitting}
            className="w-full bg-red-600 text-white py-6 rounded-2xl font-black text-sm uppercase tracking-widest shadow-2xl shadow-red-200 hover:bg-red-700 active:scale-95 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
          >
            {isSubmitting ? <RefreshCw className="animate-spin" /> : <Save />}
            {isSubmitting ? 'MENGIRIM LAPORAN...' : 'SIMPAN DATA ARMADA'}
          </button>
        </form>
      </div>
    </div>
  );
};

const CheckItem = ({ label, field, value, onChange }: any) => (
  <div className="space-y-2 group">
    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">{label}</label>
    <div className="flex bg-slate-50 p-1 rounded-xl border border-slate-100">
      <button 
        type="button"
        onClick={() => onChange(field, InspectionStatus.AMAN)}
        className={`flex-1 py-2 rounded-lg text-[9px] font-black uppercase transition-all ${value === InspectionStatus.AMAN ? 'bg-green-600 text-white shadow-md' : 'text-slate-400 hover:bg-white'}`}
      >
        AMAN
      </button>
      <button 
        type="button"
        onClick={() => onChange(field, InspectionStatus.PERBAIKAN)}
        className={`flex-1 py-2 rounded-lg text-[9px] font-black uppercase transition-all ${value === InspectionStatus.PERBAIKAN ? 'bg-red-600 text-white shadow-md' : 'text-slate-400 hover:bg-white'}`}
      >
        RUSAK
      </button>
    </div>
  </div>
);

export default ChecklistForm;
