
import React, { useMemo, useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { AlertCircle, Bell, AlertTriangle, Sparkles, RefreshCw, ShieldCheck, BrainCircuit, Save, Zap } from 'lucide-react';
import { InspectionData, ReadinessStatus, AIConfig } from '../types';
import { generateDailySummary } from '../services/geminiService';

interface Props {
  reports: InspectionData[];
  userRole: 'admin' | 'petugas' | null;
  aiConfig: AIConfig;
  onUpdateAiConfig: (config: AIConfig) => void;
}

const Dashboard: React.FC<Props> = ({ reports, userRole, aiConfig, onUpdateAiConfig }) => {
  const [summary, setSummary] = useState<string>('');
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [draftPrompt, setDraftPrompt] = useState(aiConfig.draftInstruction);
  const [summaryPrompt, setSummaryPrompt] = useState(aiConfig.summaryInstruction);

  useEffect(() => {
    if (reports.length > 0) {
      handleGetSummary();
    }
  }, [reports, aiConfig.summaryInstruction]);

  const stats = useMemo(() => {
    const ready = reports.filter(r => r.status === ReadinessStatus.SIAGA).length;
    const limited = reports.filter(r => r.status === ReadinessStatus.SIAGA_TERBATAS).length;
    const off = reports.filter(r => r.status === ReadinessStatus.OFF_SERVICE).length;
    return { ready, limited, off, total: reports.length };
  }, [reports]);

  const chartData = useMemo(() => {
    return [
      { name: 'SIAGA', total: stats.ready, color: '#16a34a' },
      { name: 'TERBATAS', total: stats.limited, color: '#ca8a04' },
      { name: 'RUSAK', total: stats.off, color: '#dc2626' },
    ];
  }, [stats]);

  const handleGetSummary = async () => {
    if (reports.length === 0) return;
    setIsSummarizing(true);
    const text = await generateDailySummary(reports, aiConfig.summaryInstruction);
    setSummary(text);
    setIsSummarizing(false);
  };

  const handleSaveConfig = () => {
    if (userRole !== 'admin') return;
    onUpdateAiConfig({
      draftInstruction: draftPrompt,
      summaryInstruction: summaryPrompt
    });
    alert('Struktur Prompt AI Telah Diperbarui!');
  };

  const handleTestAnalysis = () => {
    if (userRole !== 'admin') return;
    handleGetSummary();
  };

  return (
    <div className="space-y-8 pb-10">
      {/* Admin Prompt Command Center - Hanya Admin */}
      {userRole === 'admin' && (
        <div className="bg-white border-2 border-slate-900 rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <BrainCircuit className="text-red-600" />
              <h3 className="text-xl font-black uppercase tracking-tight italic">Kendali Struktur AI</h3>
            </div>
            <button 
              onClick={handleTestAnalysis}
              className="flex items-center gap-2 text-red-600 bg-red-50 px-4 py-2 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-red-100 transition-all"
            >
              <Zap size={14} /> Test Analisis & Bypass
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-3">
              <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Instruksi Draf (Perintah AI)</label>
              <textarea 
                className="w-full h-40 p-5 bg-slate-50 border-2 border-slate-100 rounded-3xl font-bold text-xs focus:border-red-600 outline-none transition-all shadow-inner"
                value={draftPrompt}
                onChange={(e) => setDraftPrompt(e.target.value)}
              />
            </div>
            <div className="space-y-3">
              <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Instruksi Ringkasan (Perintah AI)</label>
              <textarea 
                className="w-full h-40 p-5 bg-slate-50 border-2 border-slate-100 rounded-3xl font-bold text-xs focus:border-red-600 outline-none transition-all shadow-inner"
                value={summaryPrompt}
                onChange={(e) => setSummaryPrompt(e.target.value)}
              />
            </div>
          </div>
          
          <div className="mt-8 flex justify-end">
            <button 
              onClick={handleSaveConfig}
              className="flex items-center gap-3 bg-slate-900 text-white px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-800 transition shadow-xl active:scale-95"
            >
              <Save size={18} /> Update Struktur AI
            </button>
          </div>
        </div>
      )}

      {/* Analysis Result - Terlihat oleh semua role */}
      {reports.length > 0 && (
        <div className="bg-slate-900 text-white rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden border border-slate-800">
          <div className="absolute top-0 right-0 w-80 h-80 bg-red-600/10 rounded-full blur-[100px] -mr-20 -mt-20"></div>
          <div className="relative flex flex-col md:flex-row gap-8 items-center">
            <div className="bg-red-600 p-5 rounded-3xl shadow-2xl shadow-red-900/40 animate-pulse">
              <Sparkles size={32} className="text-white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h3 className="text-xs font-black uppercase tracking-[0.3em] text-red-500 italic">Hasil Analisis Otomatis</h3>
                <div className="h-px flex-1 bg-slate-800"></div>
              </div>
              {isSummarizing ? (
                <div className="flex items-center gap-2 text-slate-400 text-xs font-bold italic py-2">
                  <RefreshCw className="animate-spin" size={14} /> Memproses data armada...
                </div>
              ) : (
                <div className="text-sm md:text-base font-medium leading-relaxed text-slate-200 bg-white/5 p-4 rounded-2xl border border-white/5">
                  {summary || "Belum ada analisis untuk hari ini."}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Stats Cards */}
      <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden divide-y md:divide-y-0 md:divide-x divide-slate-100 flex flex-col md:flex-row">
        <StatItem label="Total Armada" value={stats.total} icon={<span className="text-xl">🚒</span>} subLabel="Unit Terdaftar" />
        <StatItem label="Siaga" value={stats.ready} icon={<ShieldCheck size={20} className="text-green-500" />} colorClass="text-green-600" subLabel="Siap Tempur" isActive={stats.ready > 0} animate="pulse" />
        <StatItem label="Terbatas" value={stats.limited} icon={<AlertTriangle size={20} className="text-yellow-500" />} colorClass="text-yellow-600" subLabel="Monitor" isActive={stats.limited > 0} />
        <StatItem label="Rusak" value={stats.off} icon={<AlertCircle size={20} className="text-red-500" />} colorClass="text-red-600" subLabel="Off-Service" isActive={stats.off > 0} animate="alert" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white rounded-[2.5rem] p-10 border border-slate-100 shadow-xl">
          <h3 className="text-lg font-black text-slate-800 uppercase tracking-tighter mb-8">Kesiapan Pos Komando</h3>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontWeight: '900', fontSize: 11}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontWeight: '900', fontSize: 11}} />
                <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.25)', padding: '20px'}} />
                <Bar dataKey="total" radius={[12, 12, 12, 12]} barSize={70}>
                  {chartData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-[2.5rem] p-10 border border-slate-100 shadow-xl">
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest mb-8 flex items-center gap-2">
            <Bell size={20} className="text-red-600" /> Kendala Teknis Terakhir
          </h3>
          <div className="space-y-5">
            {reports.filter(r => r.status !== ReadinessStatus.SIAGA).length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center opacity-30">
                <ShieldCheck size={64} className="text-slate-200 mb-4" />
                <p className="text-[10px] font-black uppercase tracking-widest">Semua Unit Aman</p>
              </div>
            ) : (
              reports.filter(r => r.status !== ReadinessStatus.SIAGA).slice(0, 6).map(report => (
                <div key={report.id} className="p-5 rounded-3xl bg-slate-50 border border-slate-100 transition-colors hover:border-red-200">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-[11px] font-black text-slate-900 uppercase">{report.unitNumber}</span>
                    <span className={`text-[9px] font-black uppercase px-3 py-1 rounded-full ${report.status === ReadinessStatus.OFF_SERVICE ? 'bg-red-100 text-red-600' : 'bg-yellow-100 text-yellow-600'}`}>
                      {report.status.split(' ')[0]}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 font-bold italic leading-relaxed">"{report.notes || 'Butuh pengecekan rutin.'}"</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const StatItem = ({ label, value, icon, colorClass = "text-slate-900", subLabel, isActive, animate }: any) => (
  <div className="flex-1 px-10 py-8 flex items-center gap-6 group hover:bg-slate-50/50 transition-colors">
    <div className={`p-4 rounded-3xl bg-slate-50 transition-all ${
      animate === 'pulse' && isActive ? 'animate-pulse bg-green-50' : 
      animate === 'alert' && isActive ? 'animate-bounce bg-red-50' : ''
    }`}>
      {icon}
    </div>
    <div>
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">{label}</p>
      <div className="flex items-baseline gap-2">
        <span className={`text-3xl font-black tracking-tighter ${colorClass}`}>{value}</span>
        <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">{subLabel}</span>
      </div>
    </div>
  </div>
);

export default Dashboard;
