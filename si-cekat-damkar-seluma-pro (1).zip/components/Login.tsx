import React, { useState } from 'react';
import { Shield, Lock, User, ChevronRight, AlertCircle, Eye, EyeOff, Flame } from 'lucide-react';

interface Props {
  onLogin: (role: 'admin' | 'petugas') => void;
}

const Login: React.FC<Props> = ({ onLogin }) => {
  const [id, setId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Admin Credential
    if (id === 'admin' && password === 'admin123') {
      onLogin('admin');
    } 
    // Petugas Credential (ID lowercase sesuai permintaan user)
    else if (id === 'petugas' && password === 'Damkar') {
      onLogin('petugas');
    } else {
      setError(true);
      setTimeout(() => setError(false), 2000);
    }
  };

  const handleIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setId(val);
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="min-h-screen bg-[#0f172a] flex flex-col items-center justify-center p-4 z-[9999] overflow-hidden relative">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-red-900/20 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-red-600/10 rounded-full blur-[120px]"></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.03]"></div>
      </div>

      <div className="w-full max-w-lg mb-12 relative z-10 flex flex-col items-center">
        <div className="text-center space-y-1">
          <h1 className="text-8xl font-black italic tracking-tighter bg-gradient-to-b from-white via-white to-slate-500 bg-clip-text text-transparent drop-shadow-[0_10px_10px_rgba(0,0,0,0.5)] select-none leading-none">
            SI-CEKAT
          </h1>
          <div className="flex items-center justify-center gap-3">
            <div className="h-[1px] w-8 bg-gradient-to-r from-transparent to-red-600"></div>
            <p className="text-sm font-black italic tracking-[0.2em] bg-gradient-to-r from-red-400 via-red-600 to-red-900 bg-clip-text text-transparent uppercase">
              Sistem Ceklis Kendaraan Teknis
            </p>
            <div className="h-[1px] w-8 bg-gradient-to-l from-transparent to-red-600"></div>
          </div>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.5em] pt-2 opacity-80">
            PEMADAM KEBAKARAN KABUPATEN SELUMA
          </p>
        </div>
      </div>
      
      <div className="w-full max-w-[400px] relative group z-10">
        <div className="absolute -inset-1 bg-gradient-to-r from-red-600 to-red-900 rounded-[2.5rem] blur opacity-25"></div>
        <div className="relative bg-white rounded-[2.5rem] shadow-2xl overflow-hidden border border-white/10">
          <div className="bg-slate-900 py-6 text-center">
            <h2 className="text-lg font-black text-white tracking-tighter uppercase italic">Otoritas Masuk</h2>
          </div>
          
          <form onSubmit={handleSubmit} className="p-8 space-y-6">
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">ID Personel</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    placeholder="petugas / admin"
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 focus:border-red-600 focus:bg-white rounded-2xl outline-none transition-all font-black text-slate-900"
                    value={id}
                    onChange={handleIdChange}
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Kata Sandi</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type={showPassword ? "text" : "password"} 
                    className="w-full pl-12 pr-12 py-4 bg-slate-50 border-2 border-slate-100 focus:border-red-600 focus:bg-white rounded-2xl outline-none transition-all font-black text-slate-900 tracking-widest"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <button type="button" onClick={togglePasswordVisibility} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300">
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>
            </div>

            {error && (
              <div className="flex items-center justify-center gap-2 p-3 bg-red-50 text-red-700 rounded-xl border border-red-100">
                <AlertCircle size={14} />
                <span className="text-[10px] font-black uppercase">ID atau Sandi Salah</span>
              </div>
            )}

            <button type="submit" className="w-full bg-red-600 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-red-700 transition shadow-xl shadow-red-200">
              MASUK SISTEM
            </button>
          </form>
        </div>
      </div>

    </div>
  );
};

export default Login;