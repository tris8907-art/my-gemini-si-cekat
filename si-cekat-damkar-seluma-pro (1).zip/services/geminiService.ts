
import { GoogleGenAI } from "@google/genai";
import { InspectionData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateDraftMessage(data: InspectionData, instruction: string) {
  try {
    const prompt = `
      Unit: ${data.unitNumber}
      Personel Pelapor: ${data.personnelName}
      Status Kesiapan: ${data.status}
      Detail Kendala: ${data.notes}
      Timestamp: ${new Date(data.timestamp).toLocaleString('id-ID')}.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: instruction
      }
    });

    return response.text;
  } catch (error) {
    console.error(error);
    return "Gagal membuat draf laporan.";
  }
}

export async function generateDailySummary(history: InspectionData[], instruction: string) {
  try {
    const prompt = `
      Analisis data pengecekan berikut:
      ${JSON.stringify(history)}
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: instruction
      }
    });

    return response.text;
  } catch (error) {
    console.error(error);
    return "Gagal memproses ringkasan.";
  }
}
